"""The comments of a text, kept in the tree: on the nodes they go with.

Each comment goes with a statement or a block of the text:

- alone on its lines, with what follows it: `before` the statement, or the `end` of the block
  whose closing brace comes next;
- after code, with the statement of that line (`after`), or the block it closes (`end_after`);
- before the first `use`, with the file (`file`); after the last graph, below it (`below`);
  above the `// @target` line, or a blank line away from what follows them, at the head of the
  text (`head`).

They are kept, as written and `//` included, in a property of what the statement makes: its node,
the frame of a block, the Group Output for the return, the zone's output node for a zone and its
return (`return_before`, `return_after`), the tree for its graph. A statement that makes no node
of its own (`b = a.x`) passes its comments to the next one. The file's comments (`head`, `file`)
go with its last graph, the one a text stands for, and so does the `// @target` line itself
(`target`): the targets a text promises stay with its tree.

Tree → Text writes them back in the same places, so that a text read back from its tree keeps
its comments, as the formatter places them.
"""

from collections import defaultdict

import blf

from ..lang import ast, ir, printer
from ..lang.lexer import tokenize
from ..lang.parser import parse

KEY = "base_node_comment"

# The nodes no statement of the text stands for: their comments cannot be written back
UNWRITTEN = ("NodeGroupInput", "NodeReroute", *ir.ZONE_INPUTS)

# The comments of a node shown above it, and below it
ABOVE = ("before", "after", "return_before", "return_after")
BELOW = ("end", "end_after")

# The boxes the Node Editor draws them in, in node units: on screen, times the UI scale and the zoom
SIZE = 11   # font size
PAD = 4     # around the text
GAP = 6     # between a box and its node
BAR = 2     # the edge on its left
LINE = 1.3  # line height, in font sizes


def is_target(text):
    return text.lstrip("/").strip().startswith("@target")


# Text -> tree


class Event:
    """A place comments go with: a statement or block opening (`open`), a block closing (`close`),
    a `use` line, the `// @target` line. `target` is (AST object, slot prefix, AST graph)."""

    def __init__(self, line, kind, target):
        self.line, self.kind, self.target = line, kind, target
        self.notes = defaultdict(list)  # slot -> comment texts


def events(file):
    """The places of the text, in its order."""
    out = [Event(u.line, "use", None) for u in sorted(file.uses, key=lambda u: u.line)]

    def walk(body, g, zone):
        for s in body:
            if isinstance(s, ast.Frame):
                out.append(Event(s.line, "open", (s, "", g)))
                walk(s.body, g, zone)
                out.append(Event(s.end, "close", (s, "", g)))
            elif isinstance(s, ast.Assign) and isinstance(s.value, ast.ZONES):
                out.append(Event(s.line, "open", (s, "", g)))
                walk(s.value.body, g, s)
                out.append(Event(s.value.end, "close", (s, "", g)))
            elif isinstance(s, ast.Return) and zone is not None:
                out.append(Event(s.line, "open", (zone, "return_", g)))
            else:
                out.append(Event(s.line, "open", (s, "", g)))

    for g in file.graphs:
        out.append(Event(g.line, "open", (g, "", g)))
        walk(g.body, g, None)
        out.append(Event(g.end, "close", (g, "", g)))
    return out


FILE_SLOTS = {"use": "file", "target": "head"}


def collect(source, filename="<text>"):
    """The places of the text, each with the comments that go with it."""
    file = parse(source, filename)
    rows = source.split("\n")
    places = events(file)
    found = [c for c in tokenize(source, filename, strict=False) if c.kind == "COMMENT"]
    promise = next((c for c in found if is_target(c.text)), None)
    if promise is not None and all(e.line > promise.line for e in places):
        places.insert(0, Event(promise.line, "target", None))
        places[0].notes["target"].append(promise.text.rstrip())
    elif places:
        # The comments at the top, a blank line before what follows, are the head of the text
        lead = [c for c in found if c.line < places[0].line and not rows[c.line - 1][:c.col - 1].strip()]
        last = lead[-1].line if lead else 0
        if lead and any(not rows[r].strip() for r in range(last, places[0].line - 1)):
            places.insert(0, Event(last + 1, "target", None))
    for c in found:
        if c is promise:
            continue
        text = c.text.rstrip()
        alone = not rows[c.line - 1][:c.col - 1].strip()
        if alone:
            e = next((e for e in places if e.line > c.line), None)
            if e is None:
                places[-1].notes["below"].append(text)  # the last graph's closing brace
            else:
                e.notes[FILE_SLOTS.get(e.kind) or ("before" if e.kind == "open" else "end")].append(text)
            continue
        on = [e for e in places if e.line == c.line]
        e = next((e for e in on if e.kind == "open"), on[0] if on else None)
        if e is None:
            # Within a statement written on several lines: with the last place before it
            e = next(e for e in reversed(places) if e.line < c.line)
        e.notes[FILE_SLOTS.get(e.kind) or ("after" if e.kind == "open" else "end_after")].append(text)
    return places


def keep(source, filename, graphs, built, made):
    """Write the comments of `source` into the trees built from it.

    `graphs` are its ir graphs, `built` their trees by name, `made` by graph name the
    (nodes, frames) the builder made: ir id -> Blender node.
    """
    by_name = {g.name: g for g in graphs if g.module is None}
    own = [built[name] for name in by_name]
    for tree in own:
        tree.pop(KEY, None)
    places = collect(source, filename)
    notes = defaultdict(lambda: defaultdict(list))  # (id, holder) -> slot -> texts
    holders = {}
    carried = []
    last = own[-1] if own else None

    for e in places:
        texts = [t for slot in ("head", "file", "before", "after", "end", "end_after", "below")
                 for t in e.notes.get(slot, [])]
        if e.kind in FILE_SLOTS:
            if last is not None:
                notes[id(last)][FILE_SLOTS[e.kind]].extend(texts)
                notes[id(last)]["target"].extend(e.notes.get("target", []))
                holders[id(last)] = last
            continue
        obj, prefix, g = e.target
        holder = resolve(obj, by_name.get(g.name), built.get(g.name), made.get(g.name, ({}, {})))
        if holder is None:
            carried.extend(texts)
            continue
        slots = notes[id(holder)]
        holders[id(holder)] = holder
        if carried:
            slots[prefix + ("before" if e.kind == "open" else "end")].extend(carried)
            carried = []
        for slot, found in e.notes.items():
            slots[slot if slot == "below" else prefix + slot].extend(found)
    if carried and last is not None:
        notes[id(last)]["below"].extend(carried)
        holders[id(last)] = last

    for i, slots in notes.items():
        written = {slot: "\n".join(texts) for slot, texts in slots.items() if texts}
        if written:
            holders[i][KEY] = written
            if getattr(holders[i], "bl_idname", None) == "NodeFrame" and not any(
                    n.parent == holders[i] for n in holders[i].id_data.nodes):
                fit_note(holders[i])


def resolve(obj, g, tree, made):
    """The tree or node that holds the comments of an AST object, or None."""
    if g is None or tree is None:
        return None
    nodes, frames = made
    if isinstance(obj, ast.Graph):
        return tree
    if isinstance(obj, ast.Return):
        return nodes.get(ir.GROUP_OUTPUT)
    if isinstance(obj, ast.Frame):
        if obj.continued:
            return None
        f = next((f for f in g.frames if (f.line, f.col) == (obj.line, obj.col)), None)
        return frames.get(f.id) if f is not None else None
    if isinstance(obj, ast.Assign):
        named = [n for n in g.nodes if n.name == obj.name]
        if not named:
            return None
        n = min(named, key=lambda n: (n.line < obj.line, abs(n.line - obj.line)))
        return nodes.get(n.id)
    return None


# Tree -> text


def plain(comment):
    """`// text` -> `text`: the comment as it reads."""
    body = comment.lstrip()
    body = body[2:] if body.startswith("//") else body
    return body[1:] if body.startswith(" ") else body


def lines_of(notes, slots):
    return [plain(c) for slot in slots for c in notes.get(slot, [])]


def wrap(lines, width, fid=0):
    """Lines cut at spaces to fit `width` pixels at the font size set; a longer word stays whole."""
    out = []
    for line in lines:
        current = ""
        for word in line.split(" "):
            tried = f"{current} {word}" if current else word
            if current and blf.dimensions(fid, tried)[0] > width:
                out.append(current)
                current = word
            else:
                current = tried
        out.append(current)
    return out


def box_height(lines, width):
    """Height of the box of these lines, `width` wide, in node units; 0 for no line."""
    if not lines:
        return 0.0
    blf.size(0, SIZE)
    shown = wrap(lines, width - BAR - 2 * PAD)
    return len(shown) * round(SIZE * LINE) + 2 * PAD


def room(node):
    """(above, below): the room its comments take over and under a node, gaps included, in node units."""
    notes = notes_of(node)
    if not notes:
        return 0.0, 0.0
    width = node.width
    above, below = box_height(lines_of(notes, ABOVE), width), box_height(lines_of(notes, BELOW), width)
    return above + GAP * bool(above), below + GAP * bool(below)


def set_comment(holder, slot, lines):
    """Write `lines`, plain text, as the comments of a slot: none removes them."""
    notes = holder.get(KEY)
    notes = notes.to_dict() if notes is not None else {}
    if lines:
        notes[slot] = "\n".join("// " + line if line else "//" for line in lines)
    else:
        notes.pop(slot, None)
    if notes:
        holder[KEY] = notes
    else:
        holder.pop(KEY, None)


def fit_note(frame):
    """Make a note, an empty frame, tall enough for the comments it shows inside."""
    lines = lines_of(notes_of(frame), BELOW)
    if not lines:
        return
    label = frame.label_size * 1.5 if frame.label else 0.0
    inner = frame.width - 2 * GAP
    frame.height = max(frame.height, label + 2 * GAP + box_height(lines, inner))


def notes_of(holder):
    found = holder.get(KEY) if holder is not None else None
    if found is None:
        return {}
    found = found.to_dict() if hasattr(found, "to_dict") else dict(found)
    return {k: v.split("\n") for k, v in found.items() if isinstance(v, str) and v}


def write(text, file, holders):
    """`text`, printed from `file`, with the comments of the trees and nodes back in it.

    `holders` maps the id of an AST object of `file` to (tree or node, slot prefix).
    """
    if not holders:
        return text
    parsed = parse(text)
    rows = text.split("\n")
    above = defaultdict(list)  # row -> lines above it
    below = defaultdict(list)  # row -> lines below it
    trail = defaultdict(list)  # row -> comments after its code
    opened = set()  # rows of `"Note" {}` written apart to hold comments

    def pad(row):
        return rows[row][:len(rows[row]) - len(rows[row].lstrip())]

    def place(a, b):
        holder, prefix = holders.get(id(a), (None, ""))
        notes = notes_of(holder)
        if not notes:
            return
        row = b.line - 1
        above[row].extend(pad(row) + t for t in notes.get(prefix + "before", []))
        trail[row].extend(notes.get(prefix + "after", []))
        if prefix:
            return  # the return of a zone: its block is the zone's
        end = b.end if isinstance(b, (ast.Frame, ast.Graph)) else b.value.end \
            if isinstance(b, ast.Assign) and isinstance(b.value, ast.ZONES) else None
        if end is None:
            return
        inside, closing = notes.get("end", []), notes.get("end_after", [])
        if end - 1 == row and (inside or closing) and rows[row].rstrip().endswith("{}"):
            opened.add(row)
            below[row].extend(pad(row) + printer.INDENT + t for t in inside)
            below[row].append("  ".join([pad(row) + "}"] + closing))
        else:
            above[end - 1].extend(pad(end - 1) + printer.INDENT + t for t in inside)
            trail[end - 1].extend(closing)
        if isinstance(b, ast.Graph):
            below[end - 1].extend(notes.get("below", []))

    def walk(sa, sb):
        for a, b in zip(sa, sb):
            place(a, b)
            if isinstance(a, ast.Frame):
                walk(a.body, b.body)
            elif isinstance(a, ast.Assign) and isinstance(a.value, ast.ZONES):
                walk(a.value.body, b.value.body)

    for ga, gb in zip(file.graphs, parsed.graphs):
        place(ga, gb)
        walk(ga.body, gb.body)

    out = []
    for i, row in enumerate(rows):
        out.extend(above[i])
        if i in opened:
            row = row.rstrip()[:-1]
        out.append("  ".join([row] + trail[i]) if trail[i] else row)
        out.extend(below[i])
    return "\n".join(out)
